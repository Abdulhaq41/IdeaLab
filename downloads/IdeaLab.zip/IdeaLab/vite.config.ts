import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({ plugins:[react(),tailwindcss()],root:'.',build:{outDir:'dist',chunkSizeWarningLimit:1000},server:{host:'0.0.0.0',allowedHosts:true}});
